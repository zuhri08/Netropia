import 'dart:math';

import 'package:flutter/material.dart';
import '../services/progress_service.dart';
import 'referensi/referensi_screen.dart';

import '../screens/learning_feature_screen.dart';
import '../services/localization_service.dart';
import 'dasar_jaringan/evaluasi_screen.dart';
import 'dasar_jaringan/penugasan_screen.dart';
import 'dasar_jaringan/portofolio_screen.dart';
import 'dasar_jaringan/post_test_screen.dart';
import 'dasar_jaringan/pre_test_screen.dart';
import 'dasar_jaringan/pengertian_jaringan_screen.dart';
import 'dasar_jaringan/refleksi_screen.dart';
import 'dasar_jaringan/video_screen.dart';
import 'ip_address/ip_address_materi_screen.dart';
import 'k3/k3_materi_screen.dart';
import 'kabel_jaringan/pengertian_kabel_screen.dart';
import 'komponen_komputer/komponen_komputer_materi_screen.dart';
import 'perangkat_jaringan/perangkat_jaringan_materi_screen.dart';
import 'dasar_jaringan/peta_konsep_screen.dart';
import 'k3/peta_konsep_k3_screen.dart';
import 'komponen_komputer/peta_konsep_komputer_screen.dart';
import 'kabel_jaringan/peta_konsep_kabel_jaringan.dart';
import 'ip_address/peta_konsep_ip_address_screen.dart';
import 'perangkat_jaringan/peta_konsep_perangkat_jaringan_screen.dart';
import 'custom_material_reader_screen.dart';

class MateriDetailLayout extends StatefulWidget {
  final String title;
  final Color themeColor;
  final VoidCallback? onMateriTap;
  final String? customMaterialContent;
  final String? customMaterialCategory;
  final String? customMaterialGuruName;

  const MateriDetailLayout({
    super.key,
    required this.title,
    this.themeColor = const Color(0xFFAD8B73),
    this.onMateriTap,
    this.customMaterialContent,
    this.customMaterialCategory,
    this.customMaterialGuruName,
  });

  @override
  State<MateriDetailLayout> createState() => _MateriDetailLayoutState();
}

class _MateriDetailLayoutState extends State<MateriDetailLayout> {
  final ProgressService _progressService = ProgressService();

  late final String _currentMotivation;

  static const List<String> _motivations = [
    'Pendidikan adalah senjata paling mematikan di dunia, karena dengan pendidikan, Anda dapat mengubah dunia. - Nelson Mandela',
    'Hiduplah seolah-olah kamu akan mati besok. Belajarlah seolah-olah kamu akan hidup selamanya. - Mahatma Gandhi',
    'Jangan pernah berhenti belajar, karena hidup tidak pernah berhenti mengajar.',
    'Kesuksesan bukanlah kunci kebahagiaan. Kebahagiaanlah kunci kesuksesan. Jika Anda mencintai apa yang Anda kerjakan, Anda akan sukses.',
    'Masa depan adalah milik mereka yang percaya pada keindahan mimpi mereka. - Eleanor Roosevelt',
    'Jenius adalah 1% inspirasi dan 99% keringat. - Thomas Alva Edison',
    'Tetaplah lapar, tetaplah bodoh. - Steve Jobs',
    'Peluang besar biasanya disamarkan sebagai kerja keras, sehingga kebanyakan orang tidak mengenalinya.',
    'Ilmu itu seperti air. Jika ia berhenti mengalir, ia menjadi keruh. - Imam Syafi\'i',
    'Barangsiapa tidak mau merasakan pahitnya belajar, ia akan merasakan hinanya kebodohan sepanjang hidupnya. - Imam Syafi\'i',
  ];

  static const Map<String, String> _englishNames = {
    'Materi': 'Material',
    'Video': 'Video',
    'Peta Konsep': 'Concept Map',
    'Referensi': 'Reference',
    'Pre Test': 'Pre Test',
    'Post Test': 'Post Test',
    'Penugasan': 'Assignment',
    'Portofolio': 'Portfolio',
    'Forum Diskusi': 'Discussion Forum',
    'Refleksi': 'Reflection',
    'Evaluasi': 'Evaluation',
    'Feedback': 'Feedback',
  };

  @override
  void initState() {
    super.initState();

    _currentMotivation =
    _motivations[Random().nextInt(_motivations.length)];
  }

  String _getEnglishName(String name) {
    return _englishNames[name] ?? name;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: localizationService,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          appBar: AppBar(
            title: Text(widget.title),
            backgroundColor: widget.themeColor,
            foregroundColor: Colors.white,
            elevation: 0,
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildGrid(),
                  const SizedBox(height: 20),
                  _buildProgressSection(),
                  const SizedBox(height: 20),
                  _buildMotivationSection(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // MENU GRID
  // ============================================================

  Widget _buildGrid() {
    final baseMenuItems = [
      {
        'name': 'Materi',
        'icon': Icons.menu_book_rounded,
        'color': widget.themeColor,
      },
      {
        'name': 'Video',
        'icon': Icons.play_circle_fill_rounded,
        'color': const Color(0xFFE53935),
      },
      {
        'name': 'Peta Konsep',
        'icon': Icons.account_tree_rounded,
        'color': const Color(0xFF00897B),
      },
      {
        'name': 'Referensi',
        'icon': Icons.library_books_rounded,
        'color': const Color(0xFFCEAB93),
      },
      {
        'name': 'Pre Test',
        'icon': Icons.assignment_rounded,
        'color': const Color(0xFFFF9800),
      },
      {
        'name': 'Post Test',
        'icon': Icons.assignment_turned_in_rounded,
        'color': const Color(0xFF43A047),
      },
      {
        'name': 'Penugasan',
        'icon': Icons.task_rounded,
        'color': const Color(0xFFE65100),
      },
      {
        'name': 'Portofolio',
        'icon': Icons.folder_shared_rounded,
        'color': const Color(0xFF8E24AA),
      },
      {
        'name': 'Forum Diskusi',
        'icon': Icons.forum_rounded,
        'color': const Color(0xFF1E88E5),
      },
      {
        'name': 'Refleksi',
        'icon': Icons.psychology_rounded,
        'color': const Color(0xFFD81B60),
      },
      {
        'name': 'Evaluasi',
        'icon': Icons.assessment_rounded,
        'color': const Color(0xFF00ACC1),
      },
      {
        'name': 'Feedback',
        'icon': Icons.feedback_rounded,
        'color': const Color(0xFF5E35B1),
      },
    ];

    final menuItems = baseMenuItems.map((item) {
      final baseColor = item['color'] as Color;
      final harmonizedColor = baseColor == widget.themeColor
          ? widget.themeColor
          : Color.lerp(baseColor, widget.themeColor, 0.55)!;
      return {
        'name': item['name'],
        'icon': item['icon'],
        'color': harmonizedColor,
      };
    }).toList();

    return LayoutBuilder(
      builder: (context, constraints) {
        final crossAxisCount = constraints.maxWidth >= 600 ? 6 : 4;

        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            mainAxisExtent: 95,
          ),
          itemCount: menuItems.length,
          itemBuilder: (context, index) {
            final item = menuItems[index];

            return _buildMenuItem(
              name: item['name'] as String,
              icon: item['icon'] as IconData,
              iconColor: item['color'] as Color,
            );
          },
        );
      },
    );
  }

  Widget _buildMenuItem({
    required String name,
    required IconData icon,
    required Color iconColor,
  }) {
    final displayName = localizationService.isEnglish
        ? _getEnglishName(name)
        : name;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _handleMenuTap(name),
        borderRadius: BorderRadius.circular(16),
        splashColor: iconColor.withOpacity(0.12),
        child: Padding(
          padding: const EdgeInsets.all(3),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: iconColor.withOpacity(0.16),
                  ),
                ),
                child: Icon(
                  icon,
                  color: iconColor,
                  size: 23,
                ),
              ),
              const SizedBox(height: 7),
              Text(
                displayName,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // MENU NAVIGATION
  // ============================================================

  void _handleMenuTap(String name) {
    if (name == 'Materi') {
      _handleMateriTap();
      return;
    }

    final materiId = _getMateriId();
    switch (name) {
      case 'Peta Konsep':
        if (materiId == 'k3') {
          _navigateTo(const PetaKonsepK3Screen());
        } else if (materiId == 'dasar_jaringan') {
          _navigateTo(const PetaKonsepScreen());
        } else if (materiId == 'komponen_komputer') {
          _navigateTo(const PetaKonsepKomputerScreen());
        } else if (materiId == 'ip_address') {
          _navigateTo(const PetaKonsepIpAddressScreen());
        }
         else if (materiId == 'kabel_jaringan') {
          _navigateTo(const PetaKonsepKabelJaringanScreen());
        } else if (materiId == 'perangkat_jaringan') {
          _navigateTo(const PetaKonsepPerangkatJaringanScreen());
        } else {
          _navigateTo(
            LearningFeatureScreen(
              materiId: materiId,
              materiTitle: widget.title,
              feature: name,
              themeColor: widget.themeColor,
            ),
          );
        }
        break;

      case 'Video':
        _navigateTo(const VideoScreen());
        break;

      case 'Referensi':
        _navigateTo(
          ReferensiScreen(
            materiId: materiId,
            materiTitle: widget.title,
          ),
        );
        break;

      case 'Pre Test':
        _navigateTo(
          PreTestScreen(
            materiId: materiId,
            materiTitle: widget.title,
            themeColor: widget.themeColor,
          ),
        );
        break;

      case 'Post Test':
        _navigateTo(
          PostTestScreen(
            materiId: materiId,
            materiTitle: widget.title,
            themeColor: widget.themeColor,
          ),
        );
        break;

      case 'Penugasan':
        _navigateTo(
          PenugasanScreen(
            materiId: materiId,
            materiTitle: widget.title,
          ),
        );
        break;

      case 'Portofolio':
        _navigateTo(
          PortofolioScreen(
            materiId: materiId,
            materiTitle: widget.title,
          ),
        );
        break;

      case 'Refleksi':
        _navigateTo(
          RefleksiScreen(
            materiId: materiId,
            materiTitle: widget.title,
          ),
        );
        break;

      case 'Evaluasi':
        _navigateTo(
          EvaluasiScreen(
            materiId: materiId,
            materiTitle: widget.title,
          ),
        );
        break;

      default:
        _navigateTo(
          LearningFeatureScreen(
            materiId: materiId,
            materiTitle: widget.title,
            feature: name,
            themeColor: widget.themeColor,
          ),
        );
    }
  }

  void _handleMateriTap() {
    if (widget.customMaterialContent != null) {
      _navigateTo(
        CustomMaterialReaderScreen(
          data: {
            'judul': widget.title,
            'kategori': widget.customMaterialCategory ?? 'Umum',
            'guruName': widget.customMaterialGuruName ?? 'Guru Netropia',
            'isi': widget.customMaterialContent,
          },
        ),
      );
      return;
    }

    final materiId = _getMateriId();

    // Callback tetap digunakan untuk materi lainnya.
    if (widget.onMateriTap != null) {
      widget.onMateriTap!();
      return;
    }

    final Widget materiScreen;

    switch (materiId) {
      case 'k3':
        materiScreen = const K3MateriScreen(index: 0);
        break;

      case 'komponen_komputer':
        materiScreen = const KomponenKomputerMateriScreen(index: 0);
        break;

      case 'perangkat_jaringan':
        materiScreen = const PerangkatJaringanMateriScreen(index: 0);
        break;

      case 'dasar_jaringan':
        materiScreen = const PengertianJaringanScreen();
        break;

      case 'kabel_jaringan':
        materiScreen = const PengertianKabelScreen();
        break;

      case 'ip_address':
        materiScreen = const IpAddressMateriScreen(index: 0);
        break;

      default:
        materiScreen = const K3MateriScreen(index: 0);
        break;
    }

    _navigateTo(materiScreen);
  }

  void _navigateTo(Widget screen) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => screen,
      ),
    );
  }

  String _getMateriId() {
    switch (widget.title) {
      case 'K3':
        return 'k3';

      case 'Komponen Komputer':
        return 'komponen_komputer';

      case 'Perangkat Jaringan':
        return 'perangkat_jaringan';

      case 'Dasar Jaringan':
        return 'dasar_jaringan';

      case 'IP Address':
        return 'ip_address';

      case 'Kabel Jaringan':
        return 'kabel_jaringan';

      default:
        return 'k3';
    }
  }

  // ============================================================
  // LEARNING PROGRESS
  // ============================================================

  Widget _buildProgressSection() {
    final materiId = _getMateriId();

    final activities = <String>[
      '${materiId}_pre_test',
      '${materiId}_post_test',
      '${materiId}_assignment',
      '${materiId}_portfolio',
      '${materiId}_peta_konsep',
      '${materiId}_forum_diskusi',
      '${materiId}_evaluasi',
    ];

    return FutureBuilder<List<bool>>(
      future: Future.wait(
        activities.map(
              (activity) => _progressService.isLessonCompleted(activity),
        ),
      ),
      builder: (context, snapshot) {
        final completed =
            snapshot.data?.where((done) => done).length ?? 0;

        final progressValue = activities.isEmpty
            ? 0.0
            : completed / activities.length;

        return Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    localizationService.translate('learning_progress'),
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).textTheme.titleMedium?.color,
                    ),
                  ),
                  Text(
                    '${(progressValue * 100).round()}%',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: widget.themeColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: progressValue,
                  minHeight: 8,
                  backgroundColor: widget.themeColor.withOpacity(0.1),
                  valueColor: AlwaysStoppedAnimation<Color>(
                    widget.themeColor,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                localizationService.isEnglish
                    ? '$completed of ${activities.length} main activities completed.'
                    : '$completed dari ${activities.length} aktivitas utama selesai.',
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ============================================================
  // DAILY MOTIVATION
  // ============================================================

  Widget _buildMotivationSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 18,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: widget.themeColor.withOpacity(0.2),
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.format_quote_rounded,
            color: widget.themeColor.withOpacity(0.5),
            size: 32,
          ),
          const SizedBox(height: 8),
          Text(
            _currentMotivation,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              fontStyle: FontStyle.italic,
              color: Theme.of(context).textTheme.bodyMedium?.color,
              height: 1.5,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            localizationService.isEnglish
                ? '- Daily Motivation -'
                : '- Motivasi Hari Ini -',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: widget.themeColor,
              letterSpacing: 1.1,
            ),
          ),
        ],
      ),
    );
  }
}