// Copyright 2025 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/// Auto-generated file. Do not edit.
public let versionNumber = "0.4.9"
