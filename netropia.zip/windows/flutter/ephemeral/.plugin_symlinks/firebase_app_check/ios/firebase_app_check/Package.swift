// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.

// Copyright 2024, the Chromium project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

import PackageDescription

let firebaseSdkVersion: Version = "12.19.3"

let package = Package(
  name: "firebase_app_check",
  platforms: [
    .iOS("15.0")
  ],
  products: [
    .library(name: "firebase-app-check", targets: ["firebase_app_check"])
  ],
  dependencies: [
    .package(url: "https://github.com/firebase/firebase-ios-sdk", exact: firebaseSdkVersion),
    .package(
      url: "https://github.com/GoogleCloudPlatform/recaptcha-enterprise-mobile-sdk.git",
      from: "18.0.0"
    ),
    .package(name: "firebase_core", path: "../firebase_core"),
    .package(name: "FlutterFramework", path: "../FlutterFramework"),
  ],
  targets: [
    .target(
      name: "firebase_app_check",
      dependencies: [
        .product(name: "FirebaseAppCheck", package: "firebase-ios-sdk"),
        .product(name: "RecaptchaEnterprise", package: "recaptcha-enterprise-mobile-sdk"),
        .product(name: "firebase-core", package: "firebase_core"),
        .product(name: "FlutterFramework", package: "FlutterFramework"),
      ],
      resources: [
        .process("Resources")
      ]
    )
  ]
)
