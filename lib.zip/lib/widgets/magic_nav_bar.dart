import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'home_effects.dart';

class MagicNavBar extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTap;
  final List<MagicNavItem> items;

  const MagicNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;
    final double itemWidth = width / items.length;
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final bool reduce = MediaQuery.of(context).disableAnimations;

    // Warna bar: Deep Espresso (mode gelap dibuat lebih pekat).
    final Color base = isDark
        ? Color.lerp(AppTheme.deepEspresso, Colors.black, 0.5)!
        : AppTheme.deepEspresso;
    final Color barTop = Color.lerp(base, Colors.white, 0.07)!;
    final Color barBottom = base;

    final Color inactiveIcon =
        AppTheme.accentTan.withOpacity(isDark ? 0.55 : 0.72);
    final Color inactiveLabel =
        AppTheme.accentTan.withOpacity(isDark ? 0.45 : 0.6);

    return FadeSlideIn(
      delay: const Duration(milliseconds: 200),
      duration: const Duration(milliseconds: 700),
      offset: const Offset(0, 50),
      child: SizedBox(
        height: 85,
        child: TweenAnimationBuilder<double>(
          // Posisi lekukan & lingkaran digerakkan bersama supaya mulus.
          tween: Tween<double>(end: currentIndex.toDouble()),
          duration: reduce ? Duration.zero : const Duration(milliseconds: 450),
          curve: Curves.easeOutCubic,
          builder: (context, pos, _) {
            final double centerX = pos * itemWidth + itemWidth / 2;

            return Stack(
              clipBehavior: Clip.none,
              children: [
                // Latar bar (gradient + lekukan yang ikut bergeser)
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: CustomPaint(
                    size: Size(width, 70),
                    painter: NavPainter(
                      centerX: centerX,
                      topColor: barTop,
                      bottomColor: barBottom,
                    ),
                  ),
                ),

                // Halo berdenyut di belakang lingkaran aktif
                Positioned(
                  left: centerX - 35,
                  top: 6,
                  child: IgnorePointer(
                    child: Pulse(
                      minScale: 0.92,
                      maxScale: 1.12,
                      duration: const Duration(milliseconds: 1500),
                      child: Container(
                        width: 70,
                        height: 70,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppTheme.secondaryBeige.withOpacity(0.16),
                        ),
                      ),
                    ),
                  ),
                ),

                // Lingkaran aktif
                Positioned(
                  left: centerX - 27.5,
                  top: 13,
                  child: Container(
                    width: 55,
                    height: 55,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [
                          AppTheme.secondaryBeige,
                          AppTheme.primaryBrown,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.secondaryBeige.withOpacity(0.45),
                          blurRadius: 14,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                  ),
                ),

                // Item navigasi
                Row(
                  children: items.asMap().entries.map((entry) {
                    final int index = entry.key;
                    final MagicNavItem item = entry.value;
                    final bool isActive = currentIndex == index;

                    final Icon icon = Icon(
                      item.icon,
                      color: isActive ? Colors.white : inactiveIcon,
                      size: isActive ? 20 : 24,
                    );

                    return Expanded(
                      child: PressScale(
                        pressedScale: 0.88,
                        child: GestureDetector(
                          onTap: () => onTap(index),
                          behavior: HitTestBehavior.opaque,
                          child: SizedBox(
                            height: 85,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                AnimatedContainer(
                                  duration: const Duration(milliseconds: 350),
                                  curve: Curves.easeOutBack,
                                  margin: EdgeInsets.only(
                                      bottom: isActive ? 8 : 0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      // Ikon aktif "pop" membal saat dipilih
                                      isActive && !reduce
                                          ? TweenAnimationBuilder<double>(
                                              tween: Tween<double>(
                                                  begin: 0.4, end: 1.0),
                                              duration: const Duration(
                                                  milliseconds: 700),
                                              curve: Curves.elasticOut,
                                              builder: (context, v, child) =>
                                                  Transform.scale(
                                                      scale: v, child: child),
                                              child: icon,
                                            )
                                          : icon,
                                      if (isActive) ...[
                                        const SizedBox(height: 1),
                                        Text(
                                          item.label,
                                          style: const TextStyle(
                                            fontSize: 8,
                                            fontWeight: FontWeight.w800,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                                if (!isActive)
                                  Positioned(
                                    bottom: 12,
                                    child: Text(
                                      item.label,
                                      style: TextStyle(
                                        fontSize: 9,
                                        fontWeight: FontWeight.w500,
                                        color: inactiveLabel,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class NavPainter extends CustomPainter {
  final double centerX;
  final Color topColor;
  final Color bottomColor;

  NavPainter({
    required this.centerX,
    required this.topColor,
    required this.bottomColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const double dipWidth = 65;
    const double dipHeight = 48;

    final Path path = Path();
    path.moveTo(0, 0);
    path.lineTo(centerX - (dipWidth + 5), 0);
    path.cubicTo(
      centerX - dipWidth / 2, 0,
      centerX - dipWidth / 2, dipHeight,
      centerX, dipHeight,
    );
    path.cubicTo(
      centerX + dipWidth / 2, dipHeight,
      centerX + dipWidth / 2, 0,
      centerX + (dipWidth + 5), 0,
    );
    path.lineTo(size.width, 0);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    final Rect rect = Offset.zero & size;
    final Paint paint = Paint()
      ..style = PaintingStyle.fill
      ..shader = LinearGradient(
        colors: [topColor, bottomColor],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(rect);

    canvas.drawShadow(path, Colors.black, 6, true);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(NavPainter oldDelegate) =>
      oldDelegate.centerX != centerX ||
      oldDelegate.topColor != topColor ||
      oldDelegate.bottomColor != bottomColor;
}

class MagicNavItem {
  final IconData icon;
  final String label;

  MagicNavItem({required this.icon, required this.label});
}
