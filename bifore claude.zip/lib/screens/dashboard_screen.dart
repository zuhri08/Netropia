import 'package:flutter/material.dart';
import '../services/progress_service.dart';
import '../services/settings_service.dart';
import '../services/notification_service.dart';
import '../absensi/attendance_screen.dart';
import '../materi/materi_screen.dart';
import '../kalkulator_subnet/subnet_calculator_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../absensi/teacher_attendance_screen.dart';
import '../peminjaman/borrowing_screen.dart';
import '../devices_3d/device_3d_list_screen.dart';
import '../peminjaman/teacher_borrowing_screen.dart';
import '../project/project_screen.dart';
import '../services/localization_service.dart';
import '../teacher/teacher_panel_screen.dart';
import 'notification_screen.dart';
import '../widgets/home_effects.dart';

class DashboardScreen extends StatelessWidget {
  final String username;
  final String role;

  const DashboardScreen({
    super.key,
    required this.username,
    required this.role,
  });

  void _openMateri(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const MateriScreen(),
      ),
    );
  }

  void _openSubnetCalculator(BuildContext context) {
    debugPrint('Membuka Kalkulator Subnet');
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const SubnetCalculatorScreen(),
      ),
    );
  }

  void _showStreakDialog(BuildContext context, int streak) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(
              Icons.local_fire_department_rounded,
              color: Colors.orange,
              size: 28,
            ),
            const SizedBox(width: 8),
            Text(localizationService.translate('streak')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$streak${localizationService.translate('streak_days')} 🔥',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.orange,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              localizationService.translate('streak_desc'),
              style: const TextStyle(fontSize: 14, height: 1.4),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(localizationService.translate('close')),
          ),
        ],
      ),
    );
  }

  void _showComingSoon(BuildContext context, String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '$feature ${localizationService.translate('coming_soon')}',
        ),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: localizationService,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          appBar: AppBar(
            backgroundColor: const Color(0xFFAD8B73),
            foregroundColor: Colors.white,
            elevation: 0,
            titleSpacing: 20,
            title: FadeSlideIn(
              offset: const Offset(-24, 0),
              child: Row(
              children: [
                const Icon(
                  Icons.school_rounded,
                  size: 28,
                ),
                const SizedBox(width: 10),
                Text(
                  localizationService.translate('netropia'),
                  style: const TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            ),
            actions: [
              FutureBuilder<int>(
                future: SettingsService().getStreak(),
                builder: (context, snapshot) {
                  final streak = snapshot.data ?? 1;
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => _showStreakDialog(context, streak),
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.08),
                                  blurRadius: 4,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Pulse(
                                  child: Icon(
                                    Icons.local_fire_department_rounded,
                                    color: Colors.orange,
                                    size: 20,
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  '$streak',
                                  style: const TextStyle(
                                    color: Color(0xFF5C3D2E),
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(width: 4),
              FutureBuilder<int>(
                future: NotificationService().getUnreadCount(),
                builder: (context, snapshot) {
                  final unreadCount = snapshot.data ?? 0;
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const NotificationScreen(),
                            ),
                          );
                        },
                        icon: unreadCount > 0
                            ? const RingingBell(
                                child: Icon(Icons.notifications_none_rounded),
                              )
                            : const Icon(Icons.notifications_none_rounded),
                      ),
                      if (unreadCount > 0)
                        Positioned(
                          top: 12,
                          right: 12,
                          child: Pulse(
                            minScale: 0.75,
                            maxScale: 1.3,
                            child: Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Colors.redAccent,
                              shape: BoxShape.circle,
                            ),
                          ),
                          ),
                        ),
                    ],
                  );
                },
              ),
              const SizedBox(width: 8),
            ],
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FadeSlideIn(
                    offset: const Offset(0, 18),
                    child: Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: '${localizationService.translate('welcome_halo')}$username ',
                          ),
                          const WidgetSpan(
                            alignment: PlaceholderAlignment.middle,
                            child: WavingHand(fontSize: 25),
                          ),
                        ],
                      ),
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).textTheme.titleLarge?.color,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 120),
                    offset: const Offset(0, 14),
                    child: Text(
                    role.toLowerCase() == 'guru'
                        ? (localizationService.isEnglish ? 'Welcome to Netropia.' : 'Selamat datang di Netropia.')
                        : localizationService.translate('welcome_subtitle'),
                    style: const TextStyle(
                      fontSize: 14,
                      color: Color(0xFF6B7280),
                    ),
                  ),
                  ),
                  const SizedBox(height: 20),
                  if (role.toLowerCase() == 'guru') ...[
                    FadeSlideIn(
                      delay: const Duration(milliseconds: 150),
                      child: _buildTeacherManagementPanel(context),
                    ),
                    FadeSlideIn(
                      delay: const Duration(milliseconds: 320),
                      child: _buildTeacherMonitoringCard(context),
                    ),
                  ] else ...[
                    FadeSlideIn(
                      delay: const Duration(milliseconds: 150),
                      child: _buildAnnouncementsCard(context),
                    ),
                    FadeSlideIn(
                      delay: const Duration(milliseconds: 280),
                      child: _buildContinueLearning(context),
                    ),
                  ],
                  const SizedBox(height: 25),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 380),
                    offset: const Offset(-20, 0),
                    child: Text(
                      localizationService.translate('home'),
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).textTheme.titleLarge?.color,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1.18,
                    children: [
                      _buildMenuCard(
                        context,
                        index: 0,
                        title: localizationService.translate('study_materials'),
                        subtitle: localizationService.translate('study_materials_desc'),
                        icon: Icons.menu_book_rounded,
                        iconColor: const Color(0xFFAD8B73),
                        backgroundColor: const Color(0xFFE8F1FF),
                        onTap: () {
                          _openMateri(context);
                        },
                      ),
                      _buildMenuCard(
                        context,
                        index: 1,
                        title: localizationService.translate('device_3d'),
                        subtitle: localizationService.translate('device_3d_desc'),
                        icon: Icons.view_in_ar_rounded,
                        iconColor: const Color(0xFF00897B),
                        backgroundColor: const Color(0xFFE5F7F4),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const Device3DListScreen(),
                            ),
                          );
                        },
                      ),
                      _buildMenuCard(
                        context,
                        index: 2,
                        title: localizationService.translate('subnet_calculator'),
                        subtitle: localizationService.translate('subnet_desc'),
                        icon: Icons.calculate_rounded,
                        iconColor: const Color(0xFFE65100),
                        backgroundColor: const Color(0xFFFFF0E6),
                        onTap: () {
                          _openSubnetCalculator(context);
                        },
                      ),
                      _buildMenuCard(
                        context,
                        index: 3,
                        title: localizationService.translate('attendance'),
                        subtitle: localizationService.translate('attendance_desc'),
                        icon: Icons.fact_check_rounded,
                        iconColor: const Color(0xFF7B1FA2),
                        backgroundColor: const Color(0xFFF3E8FF),
                        onTap: () async {
                          final user = FirebaseAuth.instance.currentUser;
                          if (user == null) return;

                          try {
                            final userDoc = await FirebaseFirestore.instance
                                .collection('users')
                                .doc(user.uid)
                                .get();
                            final role = userDoc.data()?['role'];

                            if (!context.mounted) return;

                            if (role == 'guru') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const TeacherAttendanceScreen(),
                                ),
                              );
                            } else {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const AttendanceScreen(),
                                ),
                              );
                            }
                          } catch (e) {
                            debugPrint('ERROR CEK ROLE ABSENSI: $e');
                          }
                        },
                      ),
                      _buildMenuCard(
                        context,
                        index: 4,
                        title: localizationService.translate('borrowing'),
                        subtitle: role.toLowerCase() == 'guru'
                            ? (localizationService.isEnglish ? 'Manage tool borrowing' : 'Kelola peminjaman alat')
                            : localizationService.translate('borrowing_desc'),
                        icon: Icons.inventory_2_rounded,
                        iconColor: const Color(0xFF0277BD),
                        backgroundColor: const Color(0xFFE3F2FD),
                        onTap: () async {
                          final user = FirebaseAuth.instance.currentUser;
                          if (user == null) return;

                          try {
                            final userDoc = await FirebaseFirestore.instance
                                .collection('users')
                                .doc(user.uid)
                                .get();
                            final userRole = userDoc.data()?['role'];

                            if (!context.mounted) return;

                            if (userRole == 'guru') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const TeacherBorrowingScreen(),
                                ),
                              );
                            } else {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const BorrowingScreen(),
                                ),
                              );
                            }
                          } catch (e) {
                            debugPrint('ERROR CEK ROLE PEMINJAMAN: $e');
                          }
                        },
                      ),
                      _buildMenuCard(
                        context,
                        index: 5,
                        title: localizationService.translate('project'),
                        subtitle: localizationService.translate('project_desc'),
                        icon: Icons.assignment_rounded,
                        iconColor: const Color(0xFF2E7D32),
                        backgroundColor: const Color(0xFFE8F5E9),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const ProjectScreen(),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 25),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        localizationService.translate('recent_activities'),
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).textTheme.titleLarge?.color,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          _showComingSoon(context, localizationService.translate('recent_activities'));
                        },
                        child: Text(localizationService.translate('see_all')),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  _buildActivityCard(
                    context,
                    index: 0,
                    icon: Icons.health_and_safety_rounded,
                    iconColor: const Color(0xFF2E7D32),
                    title: 'K3LH',
                    subtitle: localizationService.translate('study_materials_desc'),
                    time: localizationService.isEnglish ? 'Today' : 'Hari ini',
                  ),
                  const SizedBox(height: 10),
                  _buildActivityCard(
                    context,
                    index: 1,
                    icon: Icons.calculate_rounded,
                    iconColor: const Color(0xFFE65100),
                    title: localizationService.translate('subnet_calculator'),
                    subtitle: localizationService.translate('subnet_desc'),
                    time: localizationService.isEnglish ? 'Not used' : 'Belum digunakan',
                  ),
                  const SizedBox(height: 10),
                  _buildActivityCard(
                    context,
                    index: 2,
                    icon: Icons.fact_check_rounded,
                    iconColor: const Color(0xFF7B1FA2),
                    title: localizationService.translate('attendance'),
                    subtitle: localizationService.translate('attendance_desc'),
                    time: localizationService.isEnglish ? 'Not checked in' : 'Belum absen',
                  ),
                  const SizedBox(height: 28),
                  _buildProgressCard(context),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildContinueLearning(BuildContext context) {
    return AnimatedHeroCard(
      colors: const [
        Color(0xFFAD8B73),
        Color(0xFFCEAB93),
      ],
      borderRadius: 20,
      padding: const EdgeInsets.all(18),
      shadowColor: const Color(0xFFAD8B73),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            localizationService.translate('continue_learning'),
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Floating(
                  amplitude: 3,
                  child: Icon(
                    Icons.menu_book_rounded,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'K3LH',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Modul Pembelajaran',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Floating(
                axis: Axis.horizontal,
                amplitude: 3,
                duration: Duration(milliseconds: 1400),
                child: Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: Colors.white,
                  size: 17,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: TweenAnimationBuilder<double>(
                    tween: Tween<double>(begin: 0, end: 0.66),
                    duration: const Duration(milliseconds: 2200),
                    curve: const Interval(0.35, 1.0, curve: Curves.easeOutCubic),
                    builder: (context, value, _) => LinearProgressIndicator(
                      value: value,
                      minHeight: 7,
                      backgroundColor: const Color(0x55FFFFFF),
                      valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              const CountUpText(
                value: 66,
                suffix: '%',
                duration: Duration(milliseconds: 2200),
                curve: Interval(0.35, 1.0, curve: Curves.easeOutCubic),
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: ElevatedButton.icon(
              onPressed: () {
                _openMateri(context);
              },
              icon: const Icon(
                Icons.play_circle_fill_rounded,
                size: 20,
              ),
              label: Text(
                localizationService.translate('continue_button'),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13.5,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: const Color(0xFFAD8B73),
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuCard(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color iconColor,
    required Color backgroundColor,
    required VoidCallback onTap,
    int index = 0,
  }) {
    final delay = Duration(milliseconds: 420 + index * 90);
    return FadeSlideIn(
      delay: delay,
      offset: const Offset(0, 34),
      scaleFrom: 0.85,
      duration: const Duration(milliseconds: 650),
      child: PressScale(
        child: GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FadeSlideIn(
                      delay: delay + const Duration(milliseconds: 250),
                      offset: Offset.zero,
                      scaleFrom: 0.2,
                      curve: Curves.elasticOut,
                      duration: const Duration(milliseconds: 900),
                      child: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: Theme.of(context).brightness == Brightness.light
                            ? backgroundColor
                            : iconColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(
                        icon,
                        color: iconColor,
                        size: 24,
                      ),
                    ),
                    ),
                    const Spacer(),
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).textTheme.bodyLarge?.color,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        color: Theme.of(context).textTheme.bodySmall?.color,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
    ),
    );
  }

  Widget _buildActivityCard(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required String time,
    int index = 0,
  }) {
    return FadeSlideIn(
      delay: Duration(milliseconds: 1000 + index * 110),
      offset: const Offset(40, 0),
      child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.035),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.10),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 22,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).textTheme.bodyLarge?.color,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11,
                    color: Theme.of(context).textTheme.bodySmall?.color,
                  ),
                ),
              ],
            ),
          ),
          Text(
            time,
            style: TextStyle(
              fontSize: 10,
              color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.5),
            ),
          ),
        ],
      ),
    ),
    );
  }

  Widget _buildProgressCard(BuildContext context) {
    return FutureBuilder<int>(
      future: ProgressService().getOverallProgress(),
      builder: (context, snapshot) {
        final progress = snapshot.data ?? 0;
        final progressVal = progress / 100.0;

        return FadeSlideIn(
          delay: const Duration(milliseconds: 1350),
          child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                localizationService.translate('learning_progress'),
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).textTheme.titleLarge?.color,
                ),
              ),
              const SizedBox(height: 15),
              Row(
                children: [
                  SizedBox(
                    width: 75,
                    height: 75,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        TweenAnimationBuilder<double>(
                          tween: Tween<double>(begin: 0, end: progressVal),
                          duration: const Duration(milliseconds: 2000),
                          curve: const Interval(0.35, 1.0, curve: Curves.easeOutCubic),
                          builder: (context, animatedValue, _) => SizedBox(
                          width: 75,
                          height: 75,
                          child: CircularProgressIndicator(
                            value: animatedValue,
                            strokeWidth: 8,
                            backgroundColor: const Color(0xFFE8EDF3),
                            valueColor: const AlwaysStoppedAnimation<Color>(
                              Color(0xFFAD8B73),
                            ),
                          ),
                        ),
                        ),
                        CountUpText(
                          value: progress,
                          suffix: '%',
                          duration: const Duration(milliseconds: 2000),
                          curve: const Interval(0.35, 1.0, curve: Curves.easeOutCubic),
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).textTheme.bodyLarge?.color,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Text(
                      localizationService.isEnglish
                          ? 'Keep improving your learning! Complete materials and practices to increase learning progress.'
                          : 'Terus tingkatkan belajarmu! Selesaikan materi dan praktik untuk meningkatkan progress belajar.',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF7B8494),
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        );
      },
    );
  }

  Widget _buildTeacherManagementPanel(BuildContext context) {
    return AnimatedHeroCard(
      colors: const [
        Color(0xFFAD8B73),
        Color(0xFF8E6F5B),
      ],
      borderRadius: 24,
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(20),
      shadowColor: Colors.black,
      shadowOpacity: 0.16,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.admin_panel_settings_rounded,
                  color: Colors.white,
                  size: 26,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Panel Utama Guru',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Pusat Kelola Pembelajaran & Fasilitas TKJ',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Sub-Section 1: KELOLA PEMBELAJARAN
          const Text(
            'KELOLA PEMBELAJARAN',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.1,
              color: Colors.white70,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _teacherActionButton(
                context,
                icon: Icons.assignment_add,
                label: 'Kelola Tugas',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherPanelScreen(initialTab: 'tugas'),
                    ),
                  );
                },
              ),
              _teacherActionButton(
                context,
                icon: Icons.quiz_rounded,
                label: 'Kelola Kuis',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherPanelScreen(initialTab: 'quiz'),
                    ),
                  );
                },
              ),
              _teacherActionButton(
                context,
                icon: Icons.note_add_rounded,
                label: 'Buat Materi',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherPanelScreen(initialTab: 'materi'),
                    ),
                  );
                },
              ),
              _teacherActionButton(
                context,
                icon: Icons.campaign_rounded,
                label: 'Pengumuman',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherPanelScreen(initialTab: 'pengumuman'),
                    ),
                  );
                },
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Sub-Section 2: KELOLA KELAS & LAB TKJ
          const Text(
            'KELOLA KELAS & LAB TKJ',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.1,
              color: Colors.white70,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _teacherActionButton(
                context,
                icon: Icons.rate_review_rounded,
                label: 'Ulasan & Refleksi',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherPanelScreen(initialTab: 'refleksi'),
                    ),
                  );
                },
              ),
              _teacherActionButton(
                context,
                icon: Icons.assessment_rounded,
                label: 'Rekap & Apresiasi',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherPanelScreen(initialTab: 'rekap'),
                    ),
                  );
                },
              ),
              _teacherActionButton(
                context,
                icon: Icons.fact_check_rounded,
                label: 'Sesi Absensi QR',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherAttendanceScreen(),
                    ),
                  );
                },
              ),
              _teacherActionButton(
                context,
                icon: Icons.inventory_2_rounded,
                label: 'Persetujuan Alat',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherBorrowingScreen(),
                    ),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTeacherMonitoringCard(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 25),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFAD8B73).withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.analytics_rounded,
                color: Color(0xFFAD8B73),
                size: 22,
              ),
              SizedBox(width: 8),
              Text(
                'Ringkasan Monitoring Kelas Guru',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Stat 1: Peminjaman Alat Menunggu Persetujuan
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('loans')
                .where('status', isEqualTo: 'menunggu')
                .snapshots(),
            builder: (context, snapshot) {
              final pendingCount = snapshot.data?.docs.length ?? 0;
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const TeacherBorrowingScreen()),
                  );
                },
                borderRadius: BorderRadius.circular(12),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: pendingCount > 0 ? Colors.orange.shade50 : const Color(0xFFE8F5E9),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          Icons.inventory_2_outlined,
                          size: 20,
                          color: pendingCount > 0 ? Colors.orange.shade800 : Colors.green.shade700,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Peminjaman Alat Menunggu',
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).textTheme.bodyLarge?.color,
                              ),
                            ),
                            Text(
                              pendingCount > 0
                                  ? '$pendingCount pengajuan alat perlu disetujui Guru'
                                  : 'Tidak ada pengajuan peminjaman baru',
                              style: TextStyle(fontSize: 11.5, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),
                      if (pendingCount > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.orange,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '$pendingCount Baru',
                            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
          const Divider(height: 18),

          // Stat 2: Refleksi Siswa Belum Ditanggapi
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('reflections')
                .orderBy('createdAt', descending: true)
                .limit(10)
                .snapshots(),
            builder: (context, snapshot) {
              final docs = snapshot.data?.docs ?? [];
              final pendingFeedback = docs.where((doc) {
                final data = doc.data() as Map<String, dynamic>;
                final fb = data['feedbackGuru']?.toString() ?? '';
                return fb.isEmpty;
              }).length;

              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TeacherPanelScreen(initialTab: 'refleksi'),
                    ),
                  );
                },
                borderRadius: BorderRadius.circular(12),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFFAD8B73).withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.rate_review_rounded,
                          size: 20,
                          color: Color(0xFFAD8B73),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Refleksi Belajar Siswa',
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).textTheme.bodyLarge?.color,
                              ),
                            ),
                            Text(
                              pendingFeedback > 0
                                  ? '$pendingFeedback refleksi siswa belum ditanggapi'
                                  : 'Seluruh refleksi siswa sudah ditanggapi',
                              style: TextStyle(fontSize: 11.5, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.chevron_right_rounded, size: 20, color: Colors.grey),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAnnouncementsCard(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('announcements').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const SizedBox();
        }

        final docs = List<QueryDocumentSnapshot>.from(snapshot.data!.docs);
        docs.sort((a, b) {
          final dataA = a.data() as Map<String, dynamic>;
          final dataB = b.data() as Map<String, dynamic>;

          final tsA = dataA['createdAt'];
          final tsB = dataB['createdAt'];

          DateTime dtA = (tsA is Timestamp) ? tsA.toDate() : DateTime.now();
          DateTime dtB = (tsB is Timestamp) ? tsB.toDate() : DateTime.now();

          return dtB.compareTo(dtA);
        });

        final displayDocs = docs.take(2).toList();

        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 20),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF8E1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.amber.shade300),
            boxShadow: [
              BoxShadow(
                color: Colors.amber.withOpacity(0.12),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Pulse(
                    minScale: 0.92,
                    maxScale: 1.12,
                    child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: const BoxDecoration(
                      color: Colors.amber,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.campaign_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'Pengumuman Dari Guru',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF7A4B00),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ...docs.map((doc) {
                final data = doc.data() as Map<String, dynamic>;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        data['judul'] ?? 'Pengumuman',
                        style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        data['isi'] ?? '',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade800,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ),
        );
      },
    );
  }

  Widget _teacherActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return PressScale(
      child: Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: const Color(0xFFAD8B73)),
              const SizedBox(width: 6),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2C2C2C),
                ),
              ),
            ],
          ),
        ),
      ),
      ),
    );
  }
}
